from __future__ import print_function

import json
import boto3
import os

def lambda_handler(event, context):
    print("Event: " + json.dumps(event))
    poolId=event['userPoolId']
    user=event['userName']
    userAttributes = event["request"]["userAttributes"]
    client = boto3.client('cognito-idp')
    
    #List to hold the updated group membership
    membershipList = []
    
    if 'custom:userRole' in userAttributes:
        groups=event["request"]["userAttributes"]["custom:userRole"]
        print("Group: "+groups)
        
        if "," in groups:
            for group in groups.strip("[]").split(','):
                group=group.strip()
                membershipList.append(group)
                create_assign_group(client, poolId, group, user)
        else:
            group=groups.strip()
            membershipList.append(group)
            create_assign_group(client,poolId,group,user)
        
        membershipList.append('PaladinCloud-ReadOnly')
        #Assign default ROLE_USER to the user
        reply = client.admin_add_user_to_group( UserPoolId=poolId, Username=user, GroupName='PaladinCloud-ReadOnly' )
        result=client.admin_list_groups_for_user( Username=user,  UserPoolId=poolId )
        allGroupList=list(map(lambda g:g['GroupName'], result['Groups']))
        groupListToRemove= list(set(allGroupList).difference(membershipList))
        print(groupListToRemove)
        remove_user_groups(client, poolId,user, groupList= groupListToRemove)
    else:
        print('User role not recieved in auth response, following basic auth flow')
        
        #Assign default ROLE_USER to the user
        reply = client.admin_add_user_to_group( UserPoolId=poolId, Username=user, GroupName='PaladinCloud-ReadOnly' )
    
    return event


def create_assign_group(client, poolId, group, user):
    try:
        print ("Trying to create group: "+group)
        response = client.create_group(GroupName=group, UserPoolId=poolId)
        reply = client.admin_add_user_to_group( UserPoolId=poolId, Username=user, GroupName=group )
    except client.exceptions.GroupExistsException:
        print ("Group already exists!!")
        reply = client.admin_add_user_to_group( UserPoolId=poolId, Username=user, GroupName=group )
        
def remove_user_groups(client, poolId, user,groupList):
    for groupName in groupList:
        print('Group '+groupName+' is not in the latest membership from IdP, removing this group membership')
        client.admin_remove_user_from_group(UserPoolId=poolId,Username=user,GroupName=groupName)