from __future__ import print_function
import base64

import json
import boto3
import os


batch = boto3.client('batch')
jobQueue = os.environ.get('JOB_QUEUE') #JOB_QUEUE:pacman-batch-jobs
jobDefinition = os.environ.get('JOB_DEFINITION') #JOB_DEFINITION:pacman-rule-engine-job:15

def lambda_handler(event, context):

    print("check whether it is SQS type or not")
    ##eventSrc  = event(['eventSource'])
    ##Check whether it is of SQS type. SQS event will have Parent Key as 'Records'
    print(event)
    if('Records' in event):
        print('I am sqs event')
        process_sqs_message(event,context)
    else:
        print("I am custom event")
        # Log the received event
        print("Received event: " + json.dumps(event, indent=2))
        if jobQueue is None or jobDefinition is None:
            print("job definition or environment not found")
            return
        return processJsonInput(event,context)

## Seperate Function to handle SQS event for Triggering Shipper Job
## Author : Anandhanatarajan Kuppusamy

def process_sqs_message(event,context):
    for record in event['Records']:
        print ("Inside process_sqs_message")
        print(record)
        payload = json.loads(record['body'])
        decoded_string = base64.b64decode( os.environ.get('CONFIG_CREDENTIALS')).decode('utf-8')
        default_pwd = decoded_string.split(":")[1]
        if( record['eventSourceARN'] == os.environ.get('RISK_SCORE_SQS_ARN') ):
            payload = json.loads(payload.get('Message'))
            risk_score_payload = """{{
                                    "jobName": "risk-score",
                                    "jobUuid": "risk-score",
                                    "jobType": "jar",
                                    "jobDesc": "Update Policy and Asset Risk Scores",
                                    "weights": {{
                                        "critical": 1,
                                        "high": 0.02,
                                        "medium": 0.002,
                                        "low": 0.0008,
                                        "max": 1,
                                        "avg": 0.005
                                    }},
                                    "environmentVariables": [{{
                                        "name": "CONFIG_SERVER_URL",
                                        "value": "{}"
                                    }}, {{
                                        "name": "CONFIG_PASSWORD",
                                        "value": "{}"
                                    }}]

                                }}""".format( os.environ.get('DEFAULT_CONFIG_URL'),  default_pwd)
            risk_score_payload = json.loads(risk_score_payload)
            merged_dict = {**payload, **risk_score_payload}
            payload = json.loads(json.dumps(merged_dict))
        elif( record['eventSourceARN'] == os.environ.get('SLA_SQS_ARN')):
            payload = json.loads(payload.get('Message'))
            sla_payload = """{{
                            "jobName": "update-sla-violations",
                            "jobUuid": "update-sla-violations",
                            "jobType": "jar",
                            "jobDesc": "Update SLA in Violation",
                            "environmentVariables": [{{
                                "name": "CONFIG_SERVER_URL",
                                "value": "{}"
                            }}, {{
                                "name": "CONFIG_PASSWORD",
                                "value": "{}"
                            }}]
                            }}""".format( os.environ.get('DEFAULT_CONFIG_URL'), default_pwd)
            sla_payload = json.loads(sla_payload)
            merged_dict = {**payload, **sla_payload}
            payload = json.loads(json.dumps(merged_dict))
        processJsonInput(payload,context)

## funcation name: processJsonInput
## Author : kkumar
## process json input from CW and submit a job with Batch
##
def processJsonInput(event,context):
    print("inside processJsonInput")
    print(event)
    jobName =  event['jobName'] + '-job'
    executableName = event['jobUuid']+"."+"jar"
    print(jobName)
    print(executableName)
    environmentVariables = event['environmentVariables']
    print(environmentVariables)

    # Check if the job name is "qualys-kb-collector-job" and adjust the heap size accordingly
    if jobName == "qualys-kb-data-collector-job":
        jvmMemParams = "-Xms8g -Xmx11g"
    else:
        jvmMemParams = "-Xms1024m -Xmx4g"

    if event.get('environmentVariables'):
        containerOverrides = {"environment": event['environmentVariables']}
    else:
        containerOverrides = {}
    # Remove the environment variables now.
    del event['environmentVariables']
    parameters = {"executableName": executableName,
                  "params": json.dumps(event),
                  "jvmMemParams": jvmMemParams,  # Updated JVM heap size
                  "ruleEngineExecutableName": "policy-engine.jar",
                  "entryPoint": "com.tmobile.pacman.executor.JobExecutor",
                  }

    return submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters)

## funcation name: submit_to_batch
## Author : kkumar
## submit a job with Batch
##
def submit_to_batch(jobQueue,jobName,jobDefinition,containerOverrides,parameters):

    try:
        # Submit a Batch Job
        print("Submiting Job ")
        response = batch.submit_job(jobQueue=jobQueue, jobName=jobName, jobDefinition=jobDefinition,
                                    containerOverrides=containerOverrides, parameters=parameters)
        # Log response from AWS Batch
        print("Response: " + json.dumps(response, indent=2))
        # Return the jobId
        jobId = response['jobId']
        return {
            'jobId': jobId
        }
    except Exception as e:
        print(e)
        message = 'Error submitting Batch Job'
        print(message)
        return message
