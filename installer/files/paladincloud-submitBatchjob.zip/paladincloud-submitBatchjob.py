from __future__ import print_function

import json
import boto3
import os

batch = boto3.client('batch')
jobQueue = os.environ['JOB_QUEUE']
jobDefinition = os.environ['JOB_DEFINITION']
qualysDefinition = os.environ['QUALYS_JOB_DEFINATION']

def lambda_handler(event, context):
    # Log the received event
    
    return processJsonInput(event,context)
        
def processJsonInput(event,context):
    qualysname = event['jobName']
    jobName =  event['jobName'] + '-job'
    executableName = event['jobUuid']+"."+"jar"
    
    if event.get('environmentVariables'):
        containerOverrides = {"environment":event['environmentVariables']}
    else:
        containerOverrides = {}
    #remove the environment variables now.    
    del event['environmentVariables']
    if qualysname =="qualys-kb-collector":
        parameters = {"executableName":executableName,
                 "params":json.dumps(event),"jvmMemParams":"-Xms4096m -Xmx7000m",
                 "ruleEngineExecutableName":"policy-engine.jar",
                 "entryPoint":"com.tmobile.pacman.executor.JobExecutor"}
    else :
        parameters = {"executableName":executableName,
                 "params":json.dumps(event),"jvmMemParams":"-Xms1024m -Xmx4548m",
                 "ruleEngineExecutableName":"policy-engine.jar",
                 "entryPoint":"com.tmobile.pacman.executor.JobExecutor"}
            
    return submit_to_batch(qualysname,jobQueue,jobName,jobDefinition,containerOverrides,parameters,qualysDefinition)        

def submit_to_batch(qualysname,jobQueue,jobName,jobDefinition,containerOverrides,parameters,qualysDefinition):

    try:
        if qualysname == "qualys-kb-collector":
            # Submit a Batch Job
            response = batch.submit_job(jobQueue=jobQueue, jobName=jobName, jobDefinition=qualysDefinition,
                                        containerOverrides=containerOverrides, parameters=parameters)
            # Log response from AWS Batch
            print("Response: " + json.dumps(response, indent=2))
            # Return the jobId
            jobId = response['jobId']
            return {
                'jobId': jobId
            }
        else:
            # Submit a Batch Job
            response = batch.submit_job(jobQueue=jobQueue, jobName=jobName, jobDefinition=jobDefinition,
                                        containerOverrides=containerOverrides, parameters=parameters)
            # Log response from AWS Batch
            print("Response: " + json.dumps(response, indent=2))
            # Return the jobId
            jobId = response['jobId']
            return {
                'jobId': jobId
            }
    except Exception as e:
            print(e)
            message = 'Error submitting Batch Job'
            print(message)
            raise Exception(message)
            
            
            