from __future__ import print_function

import boto3
import json
import os
import re

import pymysql

batch = boto3.client('batch')
jobQueue = os.environ['JOB_QUEUE']
jobDefinition = os.environ['JOB_DEFINITION']
complete_jdbc_url = os.environ['RDS_URL']
db_user = os.environ['RDS_USERNAME']
db_password = os.environ['RDS_PASSWORD']


def lambda_handler(event, context):
    # include pymysql while creating zip
    # Log the received event
    print("Received event: " + json.dumps(event, indent=2))
    if 'Records' in event and 'eventSource' in event['Records'][0] and event['Records'][0]['eventSource'] == 'aws:sqs':
        return process_sqs_message(event)
    else:
        return process_json_input(event, context)


def submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters):
    try:
        # Submit a Batch Job
        response = batch.submit_job(jobQueue=jobQueue, jobName=jobName, jobDefinition=jobDefinition,
                                    containerOverrides=containerOverrides, parameters=parameters)
        # Log response from AWS Batch
        print("Response: " + json.dumps(response, indent=2))
        # Return the jobId
        jobId = response['jobId']
        return {
            'jobId': jobId
        }
    except Exception as e:
        print(e)
        message = 'Error submitting Batch Job'
        print(message)
        raise Exception(message)


def process_json_input(event, context):
    # job name cannot be more than 128 characters for AWS batch
    jobName = event['policyUUID'][0:123] + '-job'
    executableName = "pac-managed-rules"

    if event.get('containerOverrides'):
        containerOverrides = event['containerOverrides']
    else:
        containerOverrides = {}

    parameters = {"executableName": executableName + ".jar",
                  "params": json.dumps(transform_event(event)), "jvmMemParams": "-Xms1024m -Xmx4g",
                  "ruleEngineExecutableName": "policy-engine.jar",
                  "entryPoint": "com.tmobile.pacman.executor.PolicyExecutor"}
    return submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters)


def process_sqs_message(event):
    job_ids = []
    # Extract SQS message and process it
    for record in event['Records']:
        sqs_body = json.loads(record['body'])

        jobName = 'policy-job'
        executableName = "pac-managed-rules"

        containerOverrides = {}  # Initialize empty overrides

        for transformed_event in get_payload(sqs_body):
            parameters = {
                "executableName": executableName + ".jar",
                "params": json.dumps(transformed_event),  # Use SQS message as JSON
                "jvmMemParams": "-Xms1024m -Xmx4g",
                "ruleEngineExecutableName": "policy-engine.jar",
                "entryPoint": "com.tmobile.pacman.executor.PolicyExecutor"
            }
            response = submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters)
            job_ids.append(response['jobId'])
    return json.dumps({'jobIds': job_ids})


def get_payload(sqs_body):
    source = sqs_body.get('source', '') or ''
    enricher = sqs_body.get('enricher', '') or ''
    if source is '' and enricher is '':
        print('either source or enricher should be present in the sqs body')
        return [{
            "source": source,
            "targetType": '',
            "enricher": enricher,
            "policyUUID": []
        }]
    try:
        # Connect to the database
        connection = create_connection()

        with connection.cursor() as cursor:
            # SQL query to fetch IDs from the database
            if enricher is not '':
                print('querying using enricher')
                sql = "SELECT targetType, policyUUID FROM cf_PolicyTable WHERE enricher = '" + enricher + "'"
            else:
                print('querying using source')
                sql = "SELECT targetType, policyUUID FROM cf_PolicyTable WHERE assetGroup = '" + source + "'"

            cursor.execute(sql)
            rows = cursor.fetchall()
            # Check if the fetched row size is zero
            if len(rows) == 0:
                print('fetched row size is zero')
                return [{
                    "source": source,
                    "targetType": '',
                    "enricher": enricher,
                    "policyUUID": []
                }]
            # Dictionary to store the transformed data
            transformed_data = {}
            for row in rows:
                target_type = row[0]
                policy_uuid = row[1]

                # If targetType is not already in the dictionary, initialize it
                if target_type not in transformed_data:
                    transformed_data[target_type] = {
                        "source": '',
                        "targetType": target_type,
                        "enricher": '',
                        "policyUUID": []
                    }

                # Append the policyUUID to the policyUUID list
                transformed_data[target_type]["policyUUID"].append(policy_uuid)

            transformed_list = list(transformed_data.values())
            return transformed_list

    except Exception as e:
        print(e)
        message = 'Error submitting Batch Job'
        print(message)

    finally:
        if connection:
            connection.close()


def transform_event(event):
    if 'policyUUID' in event:
        policy_uuid = event['policyUUID']
        try:
            connection = create_connection()
            if not connection:
                return None

            sql_query = "select assetGroup, targetType from cf_PolicyTable where policyUUID = '" + policy_uuid + "'"

            with connection.cursor() as cursor:
                # Execute the SQL query
                cursor.execute(sql_query)

                # Fetch the first row
                row = cursor.fetchone()

                # Check if row is not empty
                if row:
                    # Store values in variables
                    source, target_type = row
                    # Create the transformed event
                    transformed_event = {
                        "source": source,
                        "targetType": target_type,
                        "enricher": '',
                        "policyUUID": [policy_uuid] if policy_uuid else []
                    }

                    return transformed_event
        except Exception as e:
            print(e)
            message = 'Error submitting Batch Job'
            print(message)
        finally:
            if connection:
                connection.close()

    # Return None if 'policyUUID' is not present in the event
    return None


def create_connection():
    match = re.match(r"jdbc:mysql://([^:/]+):(\d+)/(.+)\?.+", complete_jdbc_url)
    if match:
        db_host = match.group(1)
        db_port = int(match.group(2))
        db_name = match.group(3)
        return pymysql.connect(host=db_host, port=db_port, user=db_user, password=db_password, db=db_name)
    return None
