from __future__ import print_function

import base64
import boto3
import json
import os
import requests

batch = boto3.client('batch')
jobQueue = os.environ['JOB_QUEUE']
jobDefinition = os.environ['JOB_DEFINITION']
decoded_credentials = base64.b64decode(os.environ['CONFIG_CREDENTIALS']).decode("utf-8")
username, password = decoded_credentials.split(":")
compliance_api = os.environ['COMPLIANCE_URL']
auth_api_url = os.environ['AUTH_API_URL']
config_server_url = os.environ['CONFIG_APP_SERVICE_URL']


def lambda_handler(event, context):
    # extract and include paladincloud-dependencies while creating zip
    # Log the received event
    print("Received event: " + json.dumps(event, indent=2))
    if 'Records' in event and 'eventSource' in event['Records'][0] and event['Records'][0]['eventSource'] == 'aws:sqs':
        return process_sqs_message(event)
    else:
        return process_json_input(event, context)


def submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters):
    try:
        # Submit a Batch Job
        response = batch.submit_job(jobQueue=jobQueue, jobName=jobName, jobDefinition=jobDefinition,
                                    containerOverrides=containerOverrides, parameters=parameters)
        # Log response from AWS Batch
        print("Response: " + json.dumps(response, indent=2))
        # Return the jobId
        jobId = response['jobId']
        return {
            'jobId': jobId
        }
    except Exception as e:
        print(e)
        message = 'Error submitting Batch Job'
        print(message)
        return message


def process_json_input(event, context):
    # job name cannot be more than 128 characters for AWS batch
    jobName = event['policyUUID'][0:123] + '-job'
    executableName = "pac-managed-rules"

    if event.get('containerOverrides'):
        containerOverrides = event['containerOverrides']
    else:
        containerOverrides = {}

    parameters = {"executableName": executableName + ".jar",
                  "params": json.dumps(get_policy_engine_params(policyUUID=event['policyUUID'])),
                  "jvmMemParams": "-Xms1024m -Xmx4g",
                  "ruleEngineExecutableName": "policy-engine.jar",
                  "entryPoint": "com.tmobile.pacman.executor.PolicyExecutor"}
    return submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters)


def process_sqs_message(event):
    job_ids = []
    # Extract SQS message and process it
    try:
        for record in event['Records']:
            sqs_body = json.loads(record['body'])

            executableName = "pac-managed-rules"

            containerOverrides = {}  # Initialize empty overrides

            for transformed_event in get_payload(sqs_body):
                jobName = 'policy-engine-' + transformed_event['source'] + '-' + transformed_event['targetType']
                parameters = {
                    "executableName": executableName + ".jar",
                    "params": json.dumps(transformed_event),  # Use SQS message as JSON
                    "jvmMemParams": "-Xms1024m -Xmx4g",
                    "ruleEngineExecutableName": "policy-engine.jar",
                    "entryPoint": "com.tmobile.pacman.executor.PolicyExecutor"
                }
                response = submit_to_batch(jobQueue, jobName, jobDefinition, containerOverrides, parameters)
                job_ids.append(response['jobId'])
        return json.dumps({'jobIds': job_ids})
    except Exception as e:
        print(e)
        message = 'Error extracting sqs message'
        print(message)
        return message


def get_payload(sqs_body):
    global connection
    source = sqs_body.get('source', '') or ''
    enricherSource = sqs_body.get('enricherSource', '') or ''
    try:
        if source == '' and enricherSource == '':
            raise Exception('Either source or enricherSource should be present in the sqs body')
        if enricherSource != '':
            print('querying using enricherSource')
            return get_policy_engine_params(enricherSource=enricherSource)
        else:
            print('querying using source')
            data_by_source = get_policy_engine_params(source=source)
            data_by_enricherSource = get_policy_engine_params(enricherSource=source)
            if data_by_source is None:
                return data_by_enricherSource
            elif data_by_enricherSource is None:
                return data_by_source
            else:
                return data_by_source + data_by_enricherSource
    except Exception as e:
        print(e)
        message = 'Error submitting Batch Job'
        print(message)


def get_credentials():
    auth = (username, password)

    # Make a GET request to the config server
    response = requests.get(config_server_url, auth=auth)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        config_json = response.json()
        property_sources = config_json.get("propertySources", [])

        if property_sources:
            source_json = property_sources[0].get("source", {})
            apiauth_info = source_json.get("apiauthinfo", "")

            return apiauth_info

        return ""
    else:
        print(f"Request failed with status code {response.status_code}")
        return ""


def get_policy_engine_params(policyUUID=None, source=None, enricherSource=None):
    if policyUUID is None and source is None and enricherSource is None:
        raise ValueError("At least one parameter should have a value")

    if sum(1 for param in [policyUUID, source, enricherSource] if param is not None) != 1:
        raise ValueError("Only one parameter should have a value")

    if policyUUID:
        base_url = f"{compliance_api}/asset-type-by-uuid?policyUUID={policyUUID}"
    else:
        url_params = {'source': source, 'enricherSource': enricherSource}
        base_url = f"{compliance_api}/asset-types-by-source"
        url_params = {key: value for key, value in url_params.items() if value is not None}
        base_url += '?' + '&'.join(f"{key}={value}" for key, value in url_params.items())

    bearer_token = get_cognito_token()
    headers = {'Authorization': f'Bearer {bearer_token}'} if bearer_token else {}

    response = requests.get(base_url, headers=headers)
    if response.status_code == 200:
        return response.json().get("data", [])
    else:
        raise Exception(f"API request failed with status code {response.status_code}")


def get_cognito_token():
    credentials = get_credentials()

    # Specify the authentication parameters for client_credentials grant type
    auth_params = {
        'grant_type': 'client_credentials',
        'scope': 'API_OPERATION/READ',
    }

    # Make a POST request to the Cognito token endpoint
    response = requests.post(
        f'{auth_api_url}/oauth2/token',
        data=auth_params,
        headers={
            'Authorization': f'Basic {credentials}',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    )

    # Check the response status code
    if response.status_code == 200:
        cognito_response = response.json()
        return cognito_response.get("access_token", "")
    else:
        raise Exception(f"Token request failed with status code {response.status_code}: {response.text}")
