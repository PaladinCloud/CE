import boto3
from datetime import datetime

def lambda_handler(event, context):
    # Initialize the AWS Batch client
    batch_client = boto3.client('batch')

    # List all job queues
    response = batch_client.describe_job_queues()

    # Check if the response contains job queues
    if 'jobQueues' in response:
        job_queues = response['jobQueues']

        if job_queues:
            for queue in job_queues:
                job_queue_name = queue['jobQueueName']

                # Describe the jobs in the current job queue
                jobs_response = batch_client.list_jobs(jobQueue=job_queue_name, jobStatus='RUNNING')

                if 'jobSummaryList' in jobs_response:
                    running_jobs = jobs_response['jobSummaryList']
                    if running_jobs:
                        for job in running_jobs:
                            job_id = job['jobId']
                            started_at_ms = job['startedAt'] if 'startedAt' in job else None

                            if started_at_ms:
                                started_at = datetime.fromtimestamp(started_at_ms / 1000.0)
                                current_time = datetime.now()
                                duration = current_time - started_at

                                # Check if duration is more than 3 hours (10800 seconds)
                                if duration.total_seconds() > 10:
                                    # Terminate the job
                                    batch_client.terminate_job(jobId=job_id, reason='Job exceeded 3 hours')

    return "Terminated jobs running for more than 3 hours."
